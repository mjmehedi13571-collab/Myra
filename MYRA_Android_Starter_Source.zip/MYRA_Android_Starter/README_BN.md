# MYRA Android AI Assistant — Starter Project

এই Kotlin Android Studio starter-এ voice input, Hinglish AI chat, Android Text-to-Speech এবং কিছু local app-opening command আছে। এটি সম্পূর্ণ master specification নয়।

## Included
- Dark red/purple MYRA UI
- Android SpeechRecognizer (`hi-IN`)
- Android TextToSpeech (ডিভাইসের TTS voice অনুযায়ী)
- Gemini `generateContent` text API
- API key settings dialog
- YouTube, WhatsApp, Instagram, Facebook, Chrome, Gmail, Maps, Settings, Calculator, Play Store, Telegram, Spotify খোলার basic command
- Local time command

## Not yet included
Gemini Live WebSocket audio streaming, custom animated Canvas orb, waveform, foreground overlay, call monitoring/answer/reject, accessibility automation, prime contacts, SMS/call actions এবং chat history এই starter-এ নেই।

## Build steps
1. Android Studio-এর সাম্প্রতিক stable version install করো।
2. ZIP extract করো।
3. Android Studio → Open → extracted `MYRA_Android_Starter` folder select করো।
4. Gradle sync-এর জন্য অপেক্ষা করো। JDK 17 এবং Android SDK Platform 35 লাগবে।
5. Emulator চালাও অথবা Android phone USB debugging দিয়ে connect করো।
6. Run ▶ চাপো এবং microphone permission allow করো।
7. ⚙ → GET API KEY → Google AI Studio-তে key তৈরি করো → app-এ paste করে Save করো।
8. Internet চালু রেখে chat ও voice test করো।

## Free use and security
- Gemini API free tier-এর model availability, rate limits ও policies পরিবর্তন হতে পারে; unlimited free use ধরে নিও না।
- এই starter API key local app preferences-এ রাখে। APK reverse-engineer করা সম্ভব; production/public release-এ mobile app-এর মধ্যে key রাখা নিরাপদ নয়। Backend proxy ব্যবহার করো।
- API usage/data policy এবং current free-tier limits Google-এর official documentation-এ যাচাই করো।
- API key কাউকে পাঠিও না এবং source control-এ commit করো না।

## Troubleshooting
- API key missing: ⚙ থেকে key save করো।
- 403/400: API key, model availability ও API configuration check করো।
- 429: rate limit বা quota শেষ হতে পারে।
- Voice unavailable: phone-এ speech recognition service enable/update করো।
- TTS silent: Android Settings → Text-to-speech output-এ voice data install করো।

## Next milestones
1. Better command parser and installed-app matching
2. Name/personality/voice settings
3. Gemini Live WebSocket native audio
4. Orb animation and waveform
5. Permission-gated call/SMS and overlay features

## APK তৈরি করার সহজ বিকল্প: GitHub Actions
এই প্রজেক্টে `.github/workflows/android-apk.yml` workflow আছে, যা GitHub-এ source রাখলে APK build করার চেষ্টা করবে। আমি এই পরিবেশে APK compile বা test করতে পারিনি, তাই build সফল হবে—এমন নিশ্চয়তা দিচ্ছি না।

1. GitHub-এ sign in করে একটি নতুন repository তৈরি করো।
2. ZIP extract করে সব ফাইল (hidden `.github` folder-সহ) repository-তে upload/commit করো।
3. Repository-এর **Actions** tab খুলে **Build MYRA APK** workflow নির্বাচন করো।
4. **Run workflow** চাপো এবং run শেষ হওয়া পর্যন্ত অপেক্ষা করো।
5. সফল হলে workflow run-এর নিচে **Artifacts** থেকে `MYRA-debug-APK` download করো। ZIP extract করে `app-debug.apk` ফোনে পাঠিয়ে install করো।
6. Android-এ প্রথমবার install করার সময় browser/file manager-কে “Install unknown apps” অনুমতি দিতে হতে পারে। শুধু নিজের তৈরি/বিশ্বস্ত APK install করো।

নোট: এই workflow-এর build-ও ব্যর্থ হতে পারে; সেক্ষেত্রে Actions-এর error log দরকার হবে। API key APK-তে দেওয়া নেই; অ্যাপ খুলে Settings থেকে আলাদাভাবে দিতে হবে।
