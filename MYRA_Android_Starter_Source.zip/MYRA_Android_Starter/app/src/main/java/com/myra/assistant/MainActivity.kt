package com.myra.assistant

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private val bg = Color.rgb(5, 5, 9)
    private val card = Color.rgb(18, 18, 27)
    private val red = Color.rgb(255, 23, 68)
    private val purple = Color.rgb(213, 0, 249)
    private val white = Color.rgb(238, 238, 244)
    private val muted = Color.rgb(155, 155, 170)
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var ttsReady = false
    private var busy = false
    private val prefs by lazy { getSharedPreferences("myra_prefs", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
        append("MYRA", "Haan! Main MYRA hoon 😊\\nType karo ya mic dabao. Gemini use karne ke liye Settings mein API key add karo.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            setBackgroundColor(bg)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleColumn.addView(TextView(this).apply {
            text = "MYRA"; textSize = 30f; setTextColor(red)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD); letterSpacing = 0.08f
        })
        titleColumn.addView(TextView(this).apply {
            text = "YOUR AI COMPANION"; textSize = 10f; setTextColor(muted); letterSpacing = 0.18f
        })
        top.addView(titleColumn, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(Button(this).apply {
            text = "⚙"; textSize = 20f; setTextColor(white); setBackgroundColor(card)
            setOnClickListener { showSettings() }
        }, LinearLayout.LayoutParams(dp(54), dp(48)))
        root.addView(top)

        val orb = TextView(this).apply {
            text = "✦"; textSize = 78f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                intArrayOf(red, purple, Color.rgb(55, 15, 80))
            ).apply { shape = android.graphics.drawable.GradientDrawable.OVAL }
            elevation = dp(8).toFloat()
        }
        val orbWrap = FrameLayout(this).apply {
            addView(orb, FrameLayout.LayoutParams(dp(178), dp(178), Gravity.CENTER))
        }
        root.addView(orbWrap, LinearLayout.LayoutParams(-1, 0, 0.9f))
        status = TextView(this).apply {
            text = "READY • Tap the mic and speak"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(muted)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(28)))

        val chatCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(card, 18)
        }
        chat = TextView(this).apply { textSize = 14f; setTextColor(white); maxLines = 8; setTextIsSelectable(true) }
        val scroll = ScrollView(this).apply { addView(chat) }
        chatCard.addView(scroll, LinearLayout.LayoutParams(-1, dp(142)))
        root.addView(chatCard, LinearLayout.LayoutParams(-1, dp(170)))

        input = EditText(this).apply {
            hint = "Message MYRA..."; setHintTextColor(muted); setTextColor(white); textSize = 15f
            setPadding(dp(14), 0, dp(14), 0); singleLine = true; background = rounded(card, 14)
        }
        val inputRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        inputRow.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        inputRow.addView(Button(this).apply {
            text = "SEND"; setTextColor(Color.WHITE); setBackgroundColor(red)
            setOnClickListener {
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) { input.setText(""); hideKeyboard(); handleUserText(text) }
            }
        }, LinearLayout.LayoutParams(dp(86), dp(52)).apply { leftMargin = dp(8) })
        root.addView(inputRow, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(10) })

        root.addView(Button(this).apply {
            text = "🎙  TAP TO TALK"; textSize = 15f; setTextColor(Color.WHITE)
            background = rounded(red, 28); setOnClickListener { startListening() }
        }, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(10) })
        root.addView(TextView(this).apply {
            text = "Hinglish • AI replies need internet and an API key"
            textSize = 10f; gravity = Gravity.CENTER; setTextColor(muted)
        }, LinearLayout.LayoutParams(-1, dp(28)))
        setContentView(root)
    }

    private fun handleUserText(text: String) {
        append("YOU", text)
        val command = text.lowercase(Locale.ROOT)
        if (command.startsWith("open ") || command.endsWith(" kholo") || command.startsWith("kholo ")) {
            val name = command.removePrefix("open ").removeSuffix(" kholo").removePrefix("kholo ").trim()
            if (openApp(name)) { reply("Haan, $name kholne ki koshish kar rahi hoon 😊"); return }
        }
        if (command in listOf("time", "what time is it", "kitne baje", "time batao")) {
            val now = java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
            reply("Abhi time $now hai 😊"); return
        }
        askGemini(text)
    }

    private fun askGemini(userText: String) {
        val key = prefs.getString("api_key", "")?.trim().orEmpty()
        if (key.isBlank()) {
            reply("API key abhi set nahi hai. Upar ⚙ dabao aur Gemini API key add karo. Basic voice aur local commands phir bhi use kar sakte ho.")
            return
        }
        if (busy) return
        busy = true
        status.text = "THINKING..."
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + Uri.encode(key))
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    }
                    val prompt = "You are MYRA, a friendly personal Android voice assistant. " +
                        "Reply naturally in Hinglish (Hindi + English mix), using Roman script. " +
                        "Keep replies warm, concise, and easy to speak aloud, usually 1-3 sentences. " +
                        "Do not claim phone actions unless the app confirms them. User says: $userText"
                    val body = JSONObject()
                        .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                        .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 300))
                    conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val response = stream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    if (code !in 200..299) {
                        val message = try { JSONObject(response).optJSONObject("error")?.optString("message") } catch (_: Exception) { null }
                        "Gemini error ($code): ${message ?: "API key, model, ya quota check karo."}"
                    } else {
                        JSONObject(response).optJSONArray("candidates")?.optJSONObject(0)
                            ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
                            ?.takeIf { it.isNotBlank() } ?: "Sorry, is baar response nahi mila. Dobara try karo."
                    }
                } catch (e: Exception) { "Connection error: ${e.localizedMessage ?: "Internet check karo."}" }
            }
            busy = false
            status.text = "READY • Tap the mic and speak"
            reply(result)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition unavailable"
            Toast.makeText(this, "Speech recognition service available nahi hai.", Toast.LENGTH_LONG).show()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "LISTENING... bolo 😊" }
                override fun onBeginningOfSpeech() { status.text = "LISTENING..." }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "PROCESSING..." }
                override fun onError(error: Int) {
                    status.text = "Ready • Try again"
                    Toast.makeText(this@MainActivity, "Voice nahi samajh aayi. Dobara try karo.", Toast.LENGTH_SHORT).show()
                }
                override fun onResults(results: Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    status.text = "READY • Tap the mic and speak"
                    if (!spoken.isNullOrBlank()) handleUserText(spoken)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "MYRA se baat karo")
            }
            sr.startListening(intent)
        }
    }

    private fun openApp(rawName: String): Boolean {
        val candidates = mapOf(
            "youtube" to listOf("com.google.android.youtube"),
            "whatsapp" to listOf("com.whatsapp"),
            "instagram" to listOf("com.instagram.android"),
            "facebook" to listOf("com.facebook.katana", "com.facebook.lite"),
            "chrome" to listOf("com.android.chrome"),
            "gmail" to listOf("com.google.android.gm"),
            "maps" to listOf("com.google.android.apps.maps"),
            "settings" to listOf("com.android.settings"),
            "calculator" to listOf("com.google.android.calculator", "com.android.calculator2"),
            "play store" to listOf("com.android.vending"),
            "telegram" to listOf("org.telegram.messenger"),
            "spotify" to listOf("com.spotify.music")
        )
        val normalized = rawName.trim().removeSuffix(" app")
        val packages = candidates[normalized] ?: return false
        for (pkg in packages) {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) { startActivity(launch); return true }
        }
        reply("$normalized app nahi mili. Check karo ki app installed hai.")
        return true
    }

    private fun showSettings() {
        val field = EditText(this).apply {
            hint = "Paste Gemini API key"
            setText(prefs.getString("api_key", ""))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), 0); addView(field)
            addView(TextView(this@MainActivity).apply {
                text = "Get a key from Google AI Studio. Keep it private. This starter stores it in app preferences; a production app should use a backend."
                textSize = 12f; setTextColor(muted); setPadding(0, dp(12), 0, 0)
            })
        }
        AlertDialog.Builder(this).setTitle("MYRA Settings").setView(container)
            .setNegativeButton("CANCEL", null)
            .setNeutralButton("GET API KEY") { _, _ ->
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey")))
            }
            .setPositiveButton("SAVE") { _, _ ->
                prefs.edit().putString("api_key", field.text.toString().trim()).apply()
                Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun reply(text: String) {
        append("MYRA", text)
        if (ttsReady) {
            tts.language = Locale("hi", "IN")
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "myra_reply")
        }
    }

    private fun append(who: String, text: String) {
        val line = if (who == "MYRA") "🔴 MYRA: $text" else "◉ $who: $text"
        chat.append(if (chat.text.isNullOrEmpty()) line else "\n\n$line")
        (chat.parent as? ScrollView)?.post { (chat.parent as? ScrollView)?.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale("hi", "IN")
    }

    private fun rounded(color: Int, radiusDp: Int) =
        android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius = dp(radiusDp).toFloat() }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(input.windowToken, 0)
    }
    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
